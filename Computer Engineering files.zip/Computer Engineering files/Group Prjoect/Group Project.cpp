#include<iostream>
#include <string>
using namespace std;


const int x=5;


 // Function to be used in the main program
void functionx()
{
	// This local variable will only work in this function
	int x;
	x = 3;
// prints to sceen interger z + x
cout << x + x;
cout << endl;
}

void functiony()
{
	// local variable for functiony
 int x;
 x = 2;
// prints to screen an addition of local variable y and global variable z

 cout << x + x;
 cout << endl;

}

int main( )
{
	// Global integer that equals to 5
	


 //executes function functionx
	functionx();

	functiony();

	cout << x;
	cout << endl;

	return 0;
}