// **********************************************************************
// Author:		<Rogelio Sergio Ramirez III>
// Class:		CSCI/CMPE 1170
// Lab 1:		Hello World!
// Date:		16JAN14
// Revised on:  01/22/2010 by etomai
//              09/01/2010 by etomai
// Comment:		The code here is meant to be revised.
//
//------------------------------------------------------------------------ 
//
// Welcome to 1170 lab!  These are comments, text that the compiler ignores.
// They are used to explain to people what the code is doing.
//
// In these first labs, you'll see a lot of code that is unfamiliar.  That's
// okay, we want you to gain familiarity as we go.  Your job today is to compile
// and run this program, make some changes, and see how your changes cause the 
// computer to do different things.
//
// To start off, this program does nothing!
//
// STEP 1:
// *compile* and *run* the program.  Make sure there are no compile errors,
// and that when it runs it brings up the black box and does nothing.
//
// STEP 2:
// Make the changes indicated in comments below.  After EVERY change, compile
// and run.  Take note of how the program changes.
//
// ************************************************************************

#include <iostream>
#include <string>
using namespace std; 

// this is the say_hello function - it does nothing
void say_hello() //this is the function say_hello it gets called in the main function
{
	// add a statement after this line to *print* the string "Hello There!" to the
	//  screen
cout << "Hello There!"; // prints to screen hello there

	// add a statement after this line to *print* the special endl character
	//  (newline) to the screen
cout << endl; // this cuases next text on new line

}

// this is the "add_stuff" function - it does nothing either
void add_stuff()
{
	// add a statement here to *declare* an int variable named thisIsMyVariable
int thisIsMyVariable; //this makes thisIsMyVariable a variable capitalization matters

	// add a statement here to *add* the numbers 17 and 21 and *assign* (store)
	//  the result in the variable thisIsMyVariable
thisIsMyVariable = 17+21; //stores the variable as the operation i have

	// add a statement here to *print* the variable thisIsMyVariable to the screen
cout << thisIsMyVariable; //prints to screen the variable

	// add a statement after this line to *print* the special endl character
	//  (newline) to the screen
cout << endl; //text on new line
}

// this is the main function: it gets *called* first when the program runs
int main( )
{
	// *** this is where the program starts execution *** //

	// this statement *calls* the say_hello function
	say_hello();

	// this statement *calls* the add_stuff function
	add_stuff();

	// for good measure, this statement *calls* the say_hello function again
	say_hello();

	// you can use the pause command to get "press any key...",
        //  or choose Run Without Debugging from the menu in Visual C++
        system( "pause" );

	// this statement *returns* an int value from the main function
	return 0;
}

/***************
 If everything went well, when you run the program it should look like:

Hello There!
38
Hello There!

***************/
