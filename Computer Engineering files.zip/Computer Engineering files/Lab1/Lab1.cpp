/////////////////////////////////////////////////////////////////////
//
// Name: <Rogelio Sergio Ramirez III>
// Date: <16JAN14>
// Class: CSCI/CMPE 1370
// Created by: Christine Reilly
//
// Program Name: Print Your Name
// Program Description: Prints your name to the console
//
/////////////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

int main()
{
/////////////////////////////////////////////////////////////////////
	// Start of your code

	cout << "Rogelio Sergio Ramirez III"; // This prints my name.

	cout << endl; //This cuases the next line of text to be on a new line.




	// End of your code
/////////////////////////////////////////////////////////////////////

	system("pause");

	return 0;
}
