/////////////////////////////////////////////////////////////////////
//
// Name: <Rogelio Sergio Ramirez III>
// Date: <Today's date>
// Class: CSCI/CMPE 1370
// Created by: Christine Reilly
//
// Program Name: Debugging - Part 1
// Program Description: Start with a buggy program and fix it
//
/////////////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

int main()
{
	// Print something to the screen
	cout << "Hello World"; //missing quotations
	cout << endl; //missing ;

	system("pause");

	return 0;
}
